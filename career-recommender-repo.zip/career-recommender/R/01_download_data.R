# 01_download_data.R
# Downloads the O*NET database and the BLS OEWS national wage file into data/raw/.
# Raw files are never edited; every later script reads from here.

library(httr2)
library(fs)
library(here)

# ---- EDIT THESE TWO LINES ---------------------------------------------------
# Check the current versions first:
#   O*NET:  https://www.onetcenter.org/database.html   (e.g. "29_3"; use the latest "text" zip)
#   BLS:    https://www.bls.gov/oes/tables.htm         (national file, e.g. "24" for May 2024)
onet_version <- "29_3"
oews_year    <- "24"
# Put a real contact in the user agent; some government sites reject anonymous scripts.
my_agent <- "career-recommender dissertation project (contact: your.email@example.com)"
# -----------------------------------------------------------------------------

raw_dir <- here("data", "raw")
dir_create(raw_dir)

fetch <- function(url, dest) {
  if (file_exists(dest)) {
    message("Already have ", path_file(dest), " -- skipping")
    return(invisible(dest))
  }
  message("Downloading ", url)
  request(url) |>
    req_user_agent(my_agent) |>
    req_retry(max_tries = 3) |>
    req_perform(path = dest)
  invisible(dest)
}

# ---- O*NET ------------------------------------------------------------------
onet_url <- sprintf("https://www.onetcenter.org/dl_files/database/db_%s_text.zip", onet_version)
onet_zip <- path(raw_dir, sprintf("db_%s_text.zip", onet_version))
fetch(onet_url, onet_zip)
unzip(onet_zip, exdir = raw_dir)   # creates data/raw/db_<version>_text/

# ---- BLS OEWS (national occupational wages and employment) -------------------
oews_url <- sprintf("https://www.bls.gov/oes/special-requests/oesm%snat.zip", oews_year)
oews_zip <- path(raw_dir, sprintf("oesm%snat.zip", oews_year))
tryCatch({
  fetch(oews_url, oews_zip)
  unzip(oews_zip, exdir = raw_dir)
}, error = function(e) {
  message("\nBLS download failed: ", conditionMessage(e),
          "\nDownload the national file manually from https://www.bls.gov/oes/tables.htm,",
          "\nunzip it, and place the .xlsx in data/raw/oesm", oews_year, "nat/")
})

message("Done. Contents of data/raw:")
print(dir_ls(raw_dir))
