# 02_tidy_onet.R
# Turns the raw O*NET text files and the BLS wage file into tidy tables keyed on SOC code.
# Outputs (data/tidy/): occupations, skills_long, knowledge_long, work_context_long,
#                       riasec_long, skills_wide, wages, occupation_master

library(tidyverse)
library(janitor)
library(readxl)
library(fs)
library(here)

# ---- Locate the raw files ----------------------------------------------------
onet_dir <- dir_ls(here("data", "raw"), type = "directory", regexp = "db_.*_text$")[1]
stopifnot(!is.na(onet_dir))
message("Using O*NET folder: ", onet_dir)

read_onet <- function(file) {
  read_tsv(path(onet_dir, file), show_col_types = FALSE, na = c("", "n/a", "NA")) |>
    clean_names()
}

# The O*NET-SOC code looks like 15-1252.00; the first 7 characters are the SOC code BLS uses.
add_soc <- function(df) mutate(df, soc = str_sub(o_net_soc_code, 1, 7))

# ---- Occupations ---------------------------------------------------------------
occupations <- read_onet("Occupation Data.txt") |>
  add_soc() |>
  select(o_net_soc_code, soc, title, description)

# ---- Skills, knowledge: importance (IM) and level (LV) ---------------------------
tidy_element <- function(df) {
  df |>
    filter(scale_id %in% c("IM", "LV")) |>
    select(o_net_soc_code, element_id, element_name, scale_id, data_value) |>
    pivot_wider(names_from = scale_id, values_from = data_value) |>
    rename(importance = IM, level = LV) |>
    add_soc()
}

skills_long    <- read_onet("Skills.txt")    |> tidy_element()
knowledge_long <- read_onet("Knowledge.txt") |> tidy_element()

# ---- Work context: the work-style dimensions (social contact, pace, structure, ...) --
# Scale CX = context rating on a 1-5 scale. Select the elements that map to work-style
# preferences; edit this list as the dimension design in Phase 3 firms up.
context_keep <- c(
  # social interaction
  "Contact With Others",
  "Face-to-Face Discussions with Individuals and Within Teams",
  "Work With or Contribute to a Work Group or Team",
  "Deal With External Customers or the Public in General",
  "Telephone Conversations",
  "Public Speaking",
  "Dealing With Unpleasant, Angry, or Discourteous People",
  "Dealing with Violent or Physically Aggressive People",
  "Physical Proximity",
  # pace, structure, autonomy
  "Time Pressure",
  "Importance of Repeating Same Tasks",
  "Importance of Being Exact or Accurate",
  "Determine Tasks, Priorities and Goals",
  "Freedom to Make Decisions",
  "Frequency of Decision Making",
  "Consequence of Error",
  "Level of Competition",
  # physical setting
  "Spend Time Sitting",
  "Spend Time Standing",
  "Indoors, Environmentally Controlled",
  "Exposed to Disease or Infections"
)

work_context_long <- read_onet("Work Context.txt") |>
  filter(scale_id == "CX", element_name %in% context_keep) |>
  select(o_net_soc_code, element_id, element_name, context = data_value) |>
  add_soc()

missing_ctx <- setdiff(context_keep, unique(work_context_long$element_name))
if (length(missing_ctx) > 0) {
  warning("Work context elements not found (check names in your O*NET version): ",
          paste(missing_ctx, collapse = "; "))
}

# ---- Interests: RIASEC / Holland code (scale OI = interest score 1-7) ---------------
riasec_long <- read_onet("Interests.txt") |>
  filter(scale_id == "OI") |>
  select(o_net_soc_code, riasec = element_name, interest = data_value) |>
  add_soc()

# ---- Wide skill matrix: one row per occupation, one column per skill (importance) ----
skills_wide <- skills_long |>
  select(o_net_soc_code, element_name, importance) |>
  pivot_wider(names_from = element_name, values_from = importance) |>
  clean_names()

# ---- BLS OEWS wages and employment ---------------------------------------------------
oews_file <- dir_ls(here("data", "raw"), recurse = TRUE, regexp = "national_M\\d{4}_dl\\.xlsx$")[1]

if (is.na(oews_file)) {
  warning("No OEWS file found in data/raw -- wages table skipped. See 01_download_data.R.")
  wages <- NULL
} else {
  wages <- read_xlsx(oews_file, na = c("*", "**", "#", "~")) |>
    clean_names() |>
    # 'broad' rows are kept because OEWS reports some occupations only at the broad level
    # (e.g. clinical laboratory technologists are 29-2010, not 29-2011).
    filter(o_group %in% c("detailed", "broad")) |>
    transmute(
      soc          = occ_code,
      oews_title   = occ_title,
      o_group,
      employment   = as.numeric(tot_emp),
      median_wage  = as.numeric(a_median),   # annual median wage, USD; NA where BLS top-codes it ("#")
      mean_wage    = as.numeric(a_mean)
    )
}

# ---- Occupation master table (O*NET occupations + wages) ----------------------------------
# Join on the exact SOC code first; where OEWS has no detailed row, fall back to the broad
# group code (first 6 characters + "0", e.g. 29-2011 -> 29-2010).
if (!is.null(wages)) {
  wages_exact <- wages |> select(soc, oews_title, employment, median_wage, mean_wage)
  wages_broad <- wages |> filter(o_group == "broad") |>
    select(broad_soc = soc, broad_title = oews_title,
           broad_emp = employment, broad_median = median_wage, broad_mean = mean_wage)

  occupation_master <- occupations |>
    left_join(wages_exact, by = "soc") |>
    mutate(broad_soc = paste0(str_sub(soc, 1, 6), "0")) |>
    left_join(wages_broad, by = "broad_soc") |>
    mutate(
      wage_source = case_when(!is.na(median_wage) ~ "detailed",
                              !is.na(broad_median) ~ "broad", TRUE ~ NA_character_),
      employment  = coalesce(employment,  broad_emp),
      median_wage = coalesce(median_wage, broad_median),
      mean_wage   = coalesce(mean_wage,   broad_mean)
    ) |>
    select(-broad_soc, -broad_title, -broad_emp, -broad_median, -broad_mean)
} else {
  occupation_master <- occupations
}

# ---- Save -------------------------------------------------------------------------------
out <- list(
  occupations = occupations, skills_long = skills_long, knowledge_long = knowledge_long,
  work_context_long = work_context_long, riasec_long = riasec_long,
  skills_wide = skills_wide, occupation_master = occupation_master
)
if (!is.null(wages)) out$wages <- wages

iwalk(out, \(df, name) write_csv(df, here("data", "tidy", paste0(name, ".csv"))))

# ---- Quick sanity checks (read these in the console) -------------------------------------
cat("\nOccupations:", nrow(occupations),
    "\nSkill rows:", nrow(skills_long),
    "\nWork-context rows:", nrow(work_context_long),
    "\nRIASEC rows:", nrow(riasec_long), "\n")
if (!is.null(wages)) {
  cat("Occupations with wage data:", sum(!is.na(occupation_master$median_wage)),
      "of", nrow(occupation_master), "\n")
}
