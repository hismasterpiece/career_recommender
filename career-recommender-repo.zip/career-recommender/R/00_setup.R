# 00_setup.R -- run once per machine
# Installs the packages used by every later script and creates the folder layout.

pkgs <- c(
  "tidyverse",  # dplyr, ggplot2, readr, tidyr, stringr
  "httr2",      # downloads and API calls (O*NET Web Services later)
  "rvest",      # scraping fallback
  "jsonlite",
  "janitor",    # clean_names()
  "readxl",     # BLS OEWS spreadsheets
  "fs",
  "here",
  "scales",
  "ggrepel"     # non-overlapping plot labels
)

missing <- setdiff(pkgs, rownames(installed.packages()))
if (length(missing) > 0) install.packages(missing)

# Folder layout (relative to the project root, which `here` finds automatically)
library(here)
for (d in c("data/raw", "data/tidy", "output/figures", "docs")) {
  dir.create(here(d), recursive = TRUE, showWarnings = FALSE)
}

# Optional but recommended for reproducibility (supports the dissertation's methods chapter):
# install.packages("renv"); renv::init()

message("Setup complete. Project root: ", here())
