# 03_eda_pilot.R
# First exploratory analysis and plots for the two pilot qualifications.
# Question: do the "alternative" careers really differ from the obvious one on
# work-style, interests and pay? This is the empirical case for the recommender.

library(tidyverse)
library(here)
library(scales)

tidy <- \(f) read_csv(here("data", "tidy", f), show_col_types = FALSE)

occ     <- tidy("occupation_master.csv")
context <- tidy("work_context_long.csv")
riasec  <- tidy("riasec_long.csv")
skills  <- tidy("skills_wide.csv")

# ---- Pilot occupations --------------------------------------------------------
# SOC codes are a starting point -- confirm each one in `occ` and edit as you refine the pilot.
# 'obvious' = the occupation most associated with the degree; 'alternative' = candidates to surface.
pilot <- tribble(
  ~qualification,     ~role_type,    ~soc,       ~label,
  "Computer Science", "obvious",     "15-1252",  "Software developer",
  "Computer Science", "alternative", "15-1212",  "Information security analyst",
  "Computer Science", "alternative", "15-1211",  "Computer systems analyst",
  "Computer Science", "alternative", "17-2061",  "Computer hardware engineer (embedded)",
  "Computer Science", "alternative", "13-1111",  "Management analyst (technical consulting)",
  "Computer Science", "alternative", "15-2051",  "Data scientist",
  "Medicine",         "obvious",     "29-1215",  "Family medicine physician",
  "Medicine",         "alternative", "29-1222",  "Pathologist",
  "Medicine",         "alternative", "19-1042",  "Medical scientist",
  "Medicine",         "alternative", "29-2011",  "Medical laboratory technologist",
  "Medicine",         "alternative", "15-2041",  "Statistician (health data)",
  "Medicine",         "alternative", "15-2051",  "Data scientist (health data)"
)

# Check which pilot SOC codes exist in the data, and fix any that do not
found <- pilot |> mutate(in_onet = soc %in% occ$soc)
print(found |> select(qualification, label, soc, in_onet))
if (any(!found$in_onet)) warning("Some pilot SOC codes were not found; fix them in `pilot` above.")

# Aggregate O*NET-SOC rows to SOC level (some SOC codes have several detailed O*NET codes)
by_soc <- \(df, value) df |> group_by(soc, across(any_of(c("element_name", "riasec")))) |>
  summarise(across(all_of(value), \(x) mean(x, na.rm = TRUE)), .groups = "drop")

ctx_soc    <- by_soc(context, "context")
riasec_soc <- by_soc(riasec, "interest")

# ---- Plot 1: work-style profile of obvious vs alternative roles ------------------
plot_ctx <- ctx_soc |>
  inner_join(pilot, by = "soc", relationship = "many-to-many") |>
  filter(element_name %in% c("Contact With Others",
                             "Face-to-Face Discussions with Individuals and Within Teams",
                             "Time Pressure", "Determine Tasks, Priorities and Goals",
                             "Importance of Repeating Same Tasks", "Spend Time Sitting"))

p1 <- ggplot(plot_ctx, aes(context, label, fill = role_type)) +
  geom_col() +
  facet_grid(qualification ~ element_name, scales = "free_y", space = "free_y") +
  scale_fill_manual(values = c(obvious = "#444444", alternative = "#1f77b4")) +
  labs(title = "Work-style profiles differ sharply within the same qualification",
       x = "O*NET work-context rating (1-5)", y = NULL, fill = NULL,
       caption = "Source: O*NET database") +
  theme_minimal(base_size = 10) + theme(legend.position = "top")

ggsave(here("output", "figures", "01_work_context_pilot.png"), p1, width = 14, height = 7, dpi = 200)

# ---- Plot 2: RIASEC interest profile heatmap -----------------------------------------
plot_riasec <- riasec_soc |>
  # Data scientist appears under both qualifications, so many-to-many is expected here
  inner_join(distinct(pilot, soc, label, qualification), by = "soc",
             relationship = "many-to-many")

p2 <- ggplot(plot_riasec, aes(riasec, label, fill = interest)) +
  geom_tile(colour = "white") +
  geom_text(aes(label = round(interest, 1)), size = 3) +
  facet_grid(qualification ~ ., scales = "free_y", space = "free_y") +
  scale_fill_gradient(low = "#f7fbff", high = "#08519c") +
  labs(title = "RIASEC interest profiles of pilot occupations", x = NULL, y = NULL,
       fill = "Interest (1-7)", caption = "Source: O*NET Interests") +
  theme_minimal(base_size = 10)

ggsave(here("output", "figures", "02_riasec_pilot.png"), p2, width = 9, height = 7, dpi = 200)

# ---- Plot 3: social contact versus pay and employment size -----------------------------
contact <- ctx_soc |> filter(element_name == "Contact With Others") |> select(soc, contact = context)

plot_pay <- occ |>
  distinct(soc, median_wage, employment) |>
  inner_join(contact, by = "soc") |>
  inner_join(pilot, by = "soc", relationship = "many-to-many") |>
  filter(!is.na(median_wage))

p3 <- ggplot(plot_pay, aes(contact, median_wage, colour = role_type, size = employment)) +
  geom_point(alpha = 0.8) +
  ggrepel::geom_text_repel(aes(label = label), size = 3, show.legend = FALSE) +
  facet_wrap(~qualification) +
  scale_y_continuous(labels = label_dollar()) +
  scale_colour_manual(values = c(obvious = "#444444", alternative = "#1f77b4")) +
  labs(title = "Alternatives with less social contact can still pay comparably",
       x = "Contact with others (O*NET, 1-5)", y = "Median annual wage (USD)",
       colour = NULL, size = "US employment",
       caption = "Sources: O*NET; BLS OEWS") +
  theme_minimal(base_size = 10)

ggsave(here("output", "figures", "03_contact_vs_pay.png"), p3, width = 12, height = 6, dpi = 200)

# ---- Summary tables to paste into the write-up ------------------------------------------------
pilot_summary <- pilot |>
  left_join(distinct(occ, soc, median_wage, employment), by = "soc") |>
  left_join(contact, by = "soc")
write_csv(pilot_summary, here("output", "pilot_summary.csv"))
print(pilot_summary)
