# 04_candidate_options.R
# Data-driven career options for each qualification.
#
# For each qualification we:
#   1. define its "core" occupations (seeds) and average their skill + knowledge profile;
#   2. score every other O*NET occupation by how closely its profile matches (cosine similarity);
#   3. keep graduate-level jobs (O*NET Job Zone >= min_job_zone);
#   4. split options into "in field" (shares the field's core knowledge) and "beyond field"
#      (similar skills, different field);
#   5. optionally apply the user's preferences (less social contact, less programming, ...).
#
# Step 2 on its own is the "qualification-only" baseline: it returns more of the obvious career.
# Step 5 is what surfaces the alternatives, which is the project's central claim.
#
# Needs: data/tidy/*.csv from 02_tidy_onet.R and the raw O*NET folder (for Job Zones).

library(tidyverse)
library(here)
library(fs)

# ---- SETTINGS: edit these ---------------------------------------------------------------
top_n         <- 40   # options printed per qualification (in field)
beyond_n      <- 20   # options printed per qualification (beyond field)
min_job_zone  <- 4    # 4 = bachelor's level, 5 = graduate degree typically needed

# Core ("obvious") occupations per qualification, as 7-character SOC codes.
# gate = O*NET knowledge areas that define the field; an occupation is "in field" if any of them
# has importance >= gate_min (scale 1-5).
qualifications <- list(
  "Computer Science" = list(
    seeds = c("15-1251", "15-1253", "15-1254"),   # programmers, QA testers, web developers
    gate = "Computers and Electronics", gate_min = 3.5
  ),
  "Medicine" = list(
    seeds = c("29-1215", "29-1216", "29-1214", "29-1221"),  # family, internal, emergency, paediatrics
    gate = c("Medicine and Dentistry", "Biology"), gate_min = 3
  )
)

# Personal preferences. Set a value to switch a filter on; NULL leaves it off.
#   max_contact      O*NET "Contact With Others" (1-5): lower = less social contact
#   max_programming  O*NET "Programming" skill importance (1-5): lower = less coding
#   min_median_wage  annual USD
prefs <- list(
  max_contact     = 4.3,
  max_programming = NULL,
  min_median_wage = NULL
)
# Example for "I do not want to code all day": prefs <- list(max_programming = 3)

# Occupations you especially want to track (shows where they rank without preferences).
watch <- c("15-1212", "15-1211", "17-2061", "13-1111", "15-2051",
           "29-1222", "19-1042", "29-2011", "15-2041", "19-1041")
# -----------------------------------------------------------------------------------------

tidy <- \(f) read_csv(here("data", "tidy", f), show_col_types = FALSE)

skills    <- tidy("skills_long.csv")
knowledge <- tidy("knowledge_long.csv")
context   <- tidy("work_context_long.csv")
occ       <- tidy("occupation_master.csv")

onet_dir <- dir_ls(here("data", "raw"), type = "directory", regexp = "db_.*_text$")[1]
job_zones <- read_tsv(path(onet_dir, "Job Zones.txt"), show_col_types = FALSE) |>
  janitor::clean_names() |>
  mutate(soc = str_sub(o_net_soc_code, 1, 7)) |>
  group_by(soc) |>
  summarise(job_zone = round(mean(job_zone)), .groups = "drop")

# ---- Feature matrix: one row per SOC code, one column per skill / knowledge area ------------
feat <- bind_rows(mutate(skills, type = "skill"), mutate(knowledge, type = "knowledge")) |>
  mutate(feature = paste(type, element_name, sep = ": ")) |>
  group_by(soc, feature) |>
  summarise(v = mean(importance, na.rm = TRUE), .groups = "drop") |>
  pivot_wider(names_from = feature, values_from = v) |>
  drop_na()                      # occupations O*NET has not rated yet are excluded

message(nrow(feat), " occupations have full skill and knowledge data (the rest cannot be scored).")

mat <- feat |> select(-soc) |> as.matrix()
rownames(mat) <- feat$soc
z <- scale(mat)                  # centre and scale each feature so common skills do not dominate

cosine <- function(z, profile) {
  as.numeric(z %*% profile) / (sqrt(rowSums(z^2)) * sqrt(sum(profile^2)))
}

# ---- Lookup tables ------------------------------------------------------------------------------
titles <- occ |> group_by(soc) |> summarise(title = first(title), .groups = "drop")

wages <- occ |>
  group_by(soc) |>
  summarise(
    median_wage = if (all(is.na(median_wage))) NA_real_ else median(median_wage, na.rm = TRUE),
    employment  = if (all(is.na(employment)))  NA_real_ else max(employment, na.rm = TRUE),
    .groups = "drop"
  )

ctx_wide <- context |>
  group_by(soc, element_name) |>
  summarise(context = mean(context, na.rm = TRUE), .groups = "drop") |>
  filter(element_name %in% c("Contact With Others", "Time Pressure",
                             "Importance of Repeating Same Tasks", "Freedom to Make Decisions")) |>
  pivot_wider(names_from = element_name, values_from = context) |>
  rename(contact = `Contact With Others`, time_pressure = `Time Pressure`,
         repetitive = `Importance of Repeating Same Tasks`, autonomy = `Freedom to Make Decisions`)

programming <- skills |>
  filter(element_name == "Programming") |>
  group_by(soc) |>
  summarise(programming = mean(importance, na.rm = TRUE), .groups = "drop")

info <- titles |>
  left_join(job_zones, by = "soc") |>
  left_join(wages, by = "soc") |>
  left_join(ctx_wide, by = "soc") |>
  left_join(programming, by = "soc")

# ---- Rank every occupation for each qualification ---------------------------------------------------
rank_one <- function(q, name) {
  seeds <- intersect(q$seeds, rownames(z))
  if (length(seeds) == 0) stop("None of the seed SOC codes for ", name, " have data.")
  message(name, ": core occupations used = ", paste(seeds, collapse = ", "))
  profile <- colMeans(z[seeds, , drop = FALSE])

  gate_score <- knowledge |>
    filter(element_name %in% q$gate) |>
    group_by(soc) |>
    summarise(gate_score = max(importance, na.rm = TRUE), .groups = "drop")

  tibble(soc = rownames(z), similarity = cosine(z, profile)) |>
    filter(!soc %in% seeds) |>
    left_join(info, by = "soc") |>
    left_join(gate_score, by = "soc") |>
    filter(job_zone >= min_job_zone) |>
    arrange(desc(similarity)) |>
    mutate(qualification = name,
           rank_qual_only = row_number(),
           in_field = coalesce(gate_score >= q$gate_min, FALSE))
}

all_options <- imap(qualifications, rank_one) |> list_rbind()

apply_prefs <- function(df) {
  if (!is.null(prefs$max_contact))     df <- filter(df, contact     <= prefs$max_contact)
  if (!is.null(prefs$max_programming)) df <- filter(df, programming <= prefs$max_programming)
  if (!is.null(prefs$min_median_wage)) df <- filter(df, median_wage >= prefs$min_median_wage)
  df
}
prefs_on <- any(!map_lgl(prefs, is.null))

show <- function(df, n) {
  df |>
    transmute(`#qual-only` = rank_qual_only, title, soc, sim = round(similarity, 2),
              zone = job_zone, contact = round(contact, 2), programming = round(programming, 1),
              wage = median_wage, jobs = employment) |>
    slice_head(n = n) |>
    print(n = n, width = Inf)
}

# ---- Print results -----------------------------------------------------------------------------------
for (nm in names(qualifications)) {
  d <- filter(all_options, qualification == nm)

  cat("\n\n==========", nm, "==========\n")
  cat("\n(A) Qualification-only baseline: best skill matches in field (no preferences)\n")
  show(filter(d, in_field), top_n)

  if (prefs_on) {
    cat("\n(B) In field, after applying your preferences\n")
    show(apply_prefs(filter(d, in_field)), top_n)

    cat("\n(C) Beyond field, after applying your preferences (similar skills, different field)\n")
    show(apply_prefs(filter(d, !in_field)), beyond_n)
  } else {
    cat("\n(C) Beyond field: similar skills, different field\n")
    show(filter(d, !in_field), beyond_n)
  }
}

cat("\n\n========== Where tracked occupations rank with NO preferences ==========\n")
all_options |>
  filter(soc %in% watch) |>
  transmute(qualification, title, soc, `#qual-only` = rank_qual_only,
            in_field, contact = round(contact, 2), programming = round(programming, 1)) |>
  arrange(qualification, `#qual-only`) |>
  print(n = Inf, width = Inf)

# ---- Save ---------------------------------------------------------------------------------------------
dir_create(here("output"))
write_csv(all_options, here("output", "candidate_options_all.csv"))
if (prefs_on) {
  write_csv(apply_prefs(all_options), here("output", "candidate_options_with_preferences.csv"))
}

# ---- Plot: top in-field options, coloured by social contact ------------------------------------------------
plot_df <- all_options |>
  filter(in_field) |>
  group_by(qualification) |>
  slice_head(n = 25) |>
  ungroup() |>
  mutate(label = fct_reorder(paste(title, qualification, sep = " | "), similarity))

p <- ggplot(plot_df, aes(similarity, label, fill = contact)) +
  geom_col() +
  facet_wrap(~qualification, scales = "free_y") +
  scale_y_discrete(labels = \(x) str_remove(x, " \\|.*$")) +
  scale_fill_viridis_c(direction = -1, na.value = "grey70", name = "Contact\nwith others") +
  labs(title = "Closest occupations by skills and knowledge (qualification-only baseline)",
       subtitle = "Colour shows social contact: the baseline favours high-contact roles",
       x = "Cosine similarity to the qualification's core occupations", y = NULL,
       caption = "Source: O*NET 29.3") +
  theme_minimal(base_size = 10)

ggsave(here("output", "figures", "04_candidate_options.png"), p, width = 14, height = 8, dpi = 200)

message("\nSaved output/candidate_options_all.csv and output/figures/04_candidate_options.png")
