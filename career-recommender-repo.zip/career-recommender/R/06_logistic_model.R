# 06_logistic_model.R
# Logistic-regression recommender + a simple test that needs no participants.
#
# IDEA
#   The similarity score (script 04) is a fixed formula. Here we let a logistic regression learn how much
#   each factor matters for "would this person accept this career?", then rank careers by that probability.
#
# SIMPLE TEST (no human participants)
#   We create 120 simulated users (12 degrees x 10 users, each with random preferences). A career counts as
#   a plausible move ("accept") when:
#     - it is within two steps of the degree's core careers in O*NET's own "Related Occupations" list
#       (a source the similarity score never sees), AND
#     - it meets the user's preferences (contact, programming, pay), with a little personal tolerance, AND
#     - 8% of ratings are flipped at random, to mimic inconsistent raters.
#   Users are split into 5 folds, so the model is always tested on users it was NOT trained on.
#   We compare three rankings:  A similarity only | B similarity + preference filter | C logistic regression.
#
# LIMIT: the "raters" are rules, so this checks that the pipeline works and what the model adds over the
#   baselines. It is not proof that real people would agree. Say so in the write-up.
#
# Needs: data/tidy/*.csv from 02_tidy_onet.R, plus Job Zones, Interests and Related Occupations in the
#   raw O*NET folder (all come with the O*NET download). Run after 02.

library(tidyverse)
library(here)
library(fs)

set.seed(42)
n_per_degree <- 10
n_folds      <- 5
flip_rate    <- 0.08
min_job_zone <- 4

# ---- Degrees: core careers (SOC) and the knowledge areas that define the field ------------------------
degrees <- list(
  "Computer Science"           = list(seeds = c("15-1251","15-1253","15-1254"), gate = "Computers and Electronics"),
  "Medicine"                   = list(seeds = c("29-1215","29-1216","29-1214","29-1221"), gate = c("Medicine and Dentistry","Biology")),
  "Nursing"                    = list(seeds = c("29-1141","29-1171"), gate = "Medicine and Dentistry"),
  "Pharmacy"                   = list(seeds = "29-1051", gate = c("Chemistry","Medicine and Dentistry")),
  "Engineering"                = list(seeds = c("17-2071","17-2141","17-2112","17-2051"), gate = "Engineering and Technology"),
  "Business"                   = list(seeds = c("11-1021","13-1111","13-1161","11-2021"), gate = "Administration and Management"),
  "Accounting and Finance"     = list(seeds = c("13-2011","13-2052","13-2031"), gate = "Economics and Accounting"),
  "Law"                        = list(seeds = c("23-1011","23-1012","23-2011"), gate = "Law and Government"),
  "Psychology"                 = list(seeds = c("19-3033","19-3034","19-3032"), gate = "Psychology"),
  "Biology"                    = list(seeds = c("19-1021","19-1022","19-1042","19-1023"), gate = "Biology"),
  "Mathematics and Statistics" = list(seeds = c("15-2041","15-2021","15-2031","15-2011"), gate = "Mathematics"),
  "Education"                  = list(seeds = c("25-2021","25-2022","25-2031","25-2012"), gate = "Education and Training")
)

# ---- Load data (same handling as script 04) ------------------------------------------------------------
tidy <- \(f) read_csv(here("data", "tidy", f), show_col_types = FALSE)
skills    <- tidy("skills_long.csv")
knowledge <- tidy("knowledge_long.csv")
context   <- tidy("work_context_long.csv")
occ       <- tidy("occupation_master.csv")

onet_dir <- dir_ls(here("data", "raw"), type = "directory", regexp = "db_.*_text$")[1]
raw <- \(f) read_tsv(path(onet_dir, f), show_col_types = FALSE) |>
  janitor::clean_names() |> mutate(soc = str_sub(o_net_soc_code, 1, 7))

job_zones <- raw("Job Zones.txt") |>
  group_by(soc) |> summarise(job_zone = round(mean(job_zone)), .groups = "drop")

# Skills + knowledge: one row per SOC, z-scored (occupations with missing ratings are dropped)
feat <- bind_rows(mutate(skills, type = "skill"), mutate(knowledge, type = "knowledge")) |>
  mutate(feature = paste(type, element_name, sep = ": ")) |>
  group_by(soc, feature) |> summarise(v = mean(importance, na.rm = TRUE), .groups = "drop") |>
  pivot_wider(names_from = feature, values_from = v) |>
  drop_na()
raw_mat <- feat |> select(-soc) |> as.matrix(); rownames(raw_mat) <- feat$soc
z <- scale(raw_mat)

# Interests (RIASEC): six scores per SOC; gaps filled with the column mean, then z-scored
ri <- raw("Interests.txt") |>
  filter(scale_id == "OI") |>
  group_by(soc, element_name) |> summarise(v = mean(data_value, na.rm = TRUE), .groups = "drop") |>
  pivot_wider(names_from = element_name, values_from = v)
ri_mat <- ri |> right_join(tibble(soc = rownames(z)), by = "soc") |> arrange(match(soc, rownames(z)))
ri_mat <- ri_mat |> select(-soc) |> mutate(across(everything(), \(x) replace_na(x, mean(x, na.rm = TRUE)))) |> as.matrix()
rownames(ri_mat) <- rownames(z)
riz <- scale(ri_mat)

# Occupation facts used for preferences
wages <- occ |> group_by(soc) |>
  summarise(wage = if (all(is.na(median_wage))) NA_real_ else median(median_wage, na.rm = TRUE), .groups = "drop")
contact <- context |> filter(element_name == "Contact With Others") |>
  group_by(soc) |> summarise(contact = mean(context, na.rm = TRUE), .groups = "drop")
programming <- skills |> filter(element_name == "Programming") |>
  group_by(soc) |> summarise(programming = mean(importance, na.rm = TRUE), .groups = "drop")

info <- tibble(soc = rownames(z)) |>
  left_join(job_zones, by = "soc") |> left_join(wages, by = "soc") |>
  left_join(contact, by = "soc") |> left_join(programming, by = "soc")

pool_soc <- info |> filter(job_zone >= min_job_zone) |> pull(soc)
contact_cut <- quantile(info$contact[info$soc %in% pool_soc], c(1/3, 2/3), na.rm = TRUE)

# O*NET Related Occupations (primary tiers) = independent source for the test labels
rel <- raw("Related Occupations.txt") |>
  filter(str_starts(relatedness_tier, "Primary")) |>
  transmute(a = soc, b = str_sub(related_o_net_soc_code, 1, 7)) |> distinct()
related_of <- \(x) unique(rel$b[rel$a %in% x])

cosine <- \(m, p) as.numeric(m %*% p) / (sqrt(rowSums(m^2)) * sqrt(sum(p^2)))

# ---- Feature rows for one degree + one set of preferences ------------------------------------------------
# cap = NA means "no preference". Used both for the simulated users and for real recommendations.
make_rows <- function(deg, c_cap = NA, p_cap = NA, w_min = NA) {
  d <- degrees[[deg]]
  seeds <- intersect(d$seeds, rownames(z))
  prof  <- colMeans(z[seeds, , drop = FALSE])
  iprof <- colMeans(riz[seeds, , drop = FALSE])
  gate_cols <- paste("knowledge:", d$gate)
  ids <- setdiff(pool_soc, seeds)
  tibble(soc = ids) |>
    mutate(
      sim  = cosine(z[ids, , drop = FALSE], prof),
      isim = cosine(riz[ids, , drop = FALSE], iprof),
      gate = apply(raw_mat[ids, gate_cols, drop = FALSE], 1, max)
    ) |>
    left_join(info, by = "soc") |>
    mutate(
      ce = if (is.na(c_cap)) 0 else if_else(is.na(contact), 0, pmax(0, contact - c_cap)),
      pe = if (is.na(p_cap)) 0 else pmax(0, programming - p_cap),
      we = if (is.na(w_min)) 0 else if_else(is.na(wage), 0, pmax(0, w_min - wage) / 10000),
      meets = as.integer(ce == 0 & pe == 0 & we == 0),
      sim_x_meets = sim * meets, isim_x_meets = isim * meets, gate_x_meets = gate * meets
    )
}

# ---- Simulate users and their ratings --------------------------------------------------------------------------
sim_user <- function(pid, deg) {
  c_cap <- sample(c(NA, contact_cut[[1]], contact_cut[[2]]), 1, prob = c(.4, .3, .3))
  p_cap <- sample(c(NA, 2.5, 3.5), 1, prob = c(.4, .3, .3))
  w_min <- sample(c(NA, 60000, 90000), 1, prob = c(.5, .25, .25))
  cj <- rnorm(1, 0, .15); pj <- rnorm(1, 0, .2)               # this rater's own tolerance

  seeds    <- intersect(degrees[[deg]]$seeds, rownames(z))
  hop1     <- setdiff(related_of(seeds), seeds)
  hop2     <- setdiff(related_of(hop1), c(seeds, hop1))
  relevant <- c(hop1, hop2)

  make_rows(deg, c_cap, p_cap, w_min) |>
    mutate(
      pid = pid, degree = deg,
      ok_c = is.na(c_cap) | (!is.na(contact) & contact <= c_cap + cj),
      ok_p = is.na(p_cap) | programming <= p_cap + pj,
      ok_w = is.na(w_min) | is.na(wage) | wage >= w_min,
      y = as.integer(soc %in% relevant & ok_c & ok_p & ok_w),
      y = if_else(runif(n()) < flip_rate, 1L - y, y)
    ) |>
    select(pid, degree, soc, y, sim, isim, gate, ce, pe, we, meets, ends_with("_x_meets"))
}

users <- tibble(pid = seq_len(length(degrees) * n_per_degree),
                degree = rep(names(degrees), each = n_per_degree))
pairs <- map2(users$pid, users$degree, sim_user) |> list_rbind()
message(nrow(users), " simulated users, ", nrow(pairs), " user-career pairs, accept rate ",
        round(mean(pairs$y), 3))

# ---- Metrics ---------------------------------------------------------------------------------------------------
auc <- function(y, s) {                       # chance a random accepted career outranks a random rejected one
  r <- rank(s); n1 <- sum(y == 1); n0 <- sum(y == 0)
  (sum(r[y == 1]) - n1 * (n1 + 1) / 2) / (n1 * n0)
}
top5 <- function(df, s) {
  df |> mutate(score = s) |> group_by(pid) |> arrange(desc(score), .by_group = TRUE) |>
    slice_head(n = 5) |> summarise(p5 = mean(y), hit = max(y), .groups = "drop") |>
    summarise(`precision@5` = mean(p5), `hit@5` = mean(hit))
}
report <- \(name, df, score) bind_cols(model = name, AUC = auc(df$y, score), top5(df, score))

# ---- Logistic regression, tested on users it has not seen --------------------------------------------------
model_cols <- c("sim", "isim", "gate", "meets", "sim_x_meets", "isim_x_meets", "gate_x_meets")

fit_std <- function(train, cols) {
  mu <- map_dbl(train[cols], mean); sdv <- map_dbl(train[cols], sd); sdv[sdv == 0] <- 1
  std <- \(d) as_tibble(map2(d[cols], seq_along(cols), \(x, i) (x - mu[i]) / sdv[i]) |> set_names(cols))
  m <- glm(reformulate(cols, "y"), data = bind_cols(y = train$y, std(train)), family = binomial)
  list(model = m, predict = \(d) predict(m, newdata = std(d), type = "link"), mu = mu, sd = sdv)
}

fold_of <- tibble(pid = users$pid, fold = sample(rep(seq_len(n_folds), length.out = nrow(users))))
pairs <- left_join(pairs, fold_of, by = "pid")
cv_score <- numeric(nrow(pairs))
for (k in seq_len(n_folds)) {
  tr <- pairs$fold != k
  cv_score[!tr] <- fit_std(pairs[tr, ], model_cols)$predict(pairs[!tr, ])
}

comparison <- bind_rows(
  report("A  similarity only",              pairs, pairs$sim),
  report("B  similarity + preference filter", pairs, pairs$meets * 10 + pairs$sim),
  report("C  logistic regression (test users)", pairs, cv_score)
)
cat("\n===== Test results (higher is better) =====\n")
print(comparison |> mutate(across(where(is.numeric), \(x) round(x, 3))), width = Inf)

# ---- Final model: coefficients = the explanation ---------------------------------------------------------------
final <- fit_std(pairs, model_cols)
coefs <- tibble(
  term = names(coef(final$model)), estimate = coef(final$model),
  odds_ratio_per_sd = exp(coef(final$model))
) |> filter(term != "(Intercept)")
cat("\n===== Final model: odds ratio per 1 SD of each factor =====\n")
print(coefs |> mutate(across(where(is.numeric), \(x) round(x, 2))))

# ---- Use the model: ranked careers for one person ----------------------------------------------------------------
recommend <- function(deg, c_cap = NA, p_cap = NA, w_min = NA, n = 20) {
  make_rows(deg, c_cap, p_cap, w_min) |>
    mutate(prob = plogis(final$predict(pick(everything())))) |>
    left_join(distinct(occ, soc, title), by = "soc") |>
    arrange(desc(prob)) |>
    transmute(rank = row_number(), title, soc, probability = round(prob, 2),
              similarity = round(sim, 2), contact = round(contact, 2), programming = round(programming, 1), wage) |>
    slice_head(n = n)
}
cat("\nExample: Computer Science graduate who wants little coding (programming <= 2.5):\n")
print(recommend("Computer Science", p_cap = 2.5, n = 15), width = Inf)

# ---- Save ------------------------------------------------------------------------------------------------------
dir_create(here("output", "figures"))
write_csv(pairs, here("output", "model_pairs.csv"))
write_csv(comparison, here("output", "model_comparison.csv"))
write_csv(coefs, here("output", "model_coefficients.csv"))

p <- comparison |>
  pivot_longer(c(AUC, `precision@5`, `hit@5`), names_to = "metric", values_to = "value") |>
  ggplot(aes(metric, value, fill = model)) + geom_col(position = "dodge") +
  labs(title = "Logistic regression vs baselines (simulated test users)", x = NULL, y = NULL, fill = NULL) +
  theme_minimal(base_size = 11) + theme(legend.position = "bottom")
ggsave(here("output", "figures", "06_model_comparison.png"), p, width = 9, height = 5, dpi = 200)
message("\nSaved model_pairs.csv, model_comparison.csv, model_coefficients.csv and figures/06_model_comparison.png")
